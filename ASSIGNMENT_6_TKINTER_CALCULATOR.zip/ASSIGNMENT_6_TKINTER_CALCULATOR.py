import tkinter as tk

# ---------------- WINDOW ----------------
window = tk.Tk()
window.title("CALCULATOR")
window.geometry("400x500")

# ---------------- ENTRY ----------------
input_window = tk.Entry(window, width=60, borderwidth=8)
input_window.place(x=10, y=20)

# ---------------- FUNCTIONS ----------------
def click_b(text):
    current = input_window.get()
    input_window.delete(0, tk.END)
    input_window.insert(0, current + str(text))

def click_clear():
    input_window.delete(0, tk.END)

def func_equal():
    expression = input_window.get()

    nums = []
    ops = []
    tmp = ""

    # split numbers and operators
    for char in expression:
        if char.isdigit():
            tmp += char
        else:
            nums.append(int(tmp))
            ops.append(char)
            tmp = ""
    nums.append(int(tmp))  # last number

    # division
    while '/' in ops:
        i = ops.index('/')
        if nums[i+1] == 0:
            input_window.delete(0, tk.END)
            input_window.insert(0, "Infinity")
            return
        result = nums[i] / nums[i+1]
        nums[i:i+2] = [result]
        ops.pop(i)

    # multiplication
    while '*' in ops:
        i = ops.index('*')
        result = nums[i] * nums[i+1]
        nums[i:i+2] = [result]
        ops.pop(i)

    # addition
    while '+' in ops:
        i = ops.index('+')
        result = nums[i] + nums[i+1]
        nums[i:i+2] = [result]
        ops.pop(i)

    # subtraction
    while '-' in ops:
        i = ops.index('-')
        result = nums[i] - nums[i+1]
        nums[i:i+2] = [result]
        ops.pop(i)

    input_window.delete(0, tk.END)
    input_window.insert(0, nums[0])

# ---------------- BUTTONS ----------------
b = tk.Button(window, text="1", width=10,background="lightblue", command=lambda: click_b(1))
b.place(x=20, y=70)

b=tk.Button(window, text="2", width=10,background="lightblue", command=lambda: click_b(2))
b.place(x=120, y=70)

b=tk.Button(window, text="3", width=10,background="lightblue", command=lambda: click_b(3))
b.place(x=220, y=70)

b=tk.Button(window, text="4", width=10,background="lightblue", command=lambda: click_b(4))
b.place(x=20, y=100)

b=tk.Button(window, text="5", width=10,background="lightblue", command=lambda: click_b(5))
b.place(x=120, y=100)

b=tk.Button(window, text="6", width=10,background="lightblue", command=lambda: click_b(6))
b.place(x=220, y=100)

b=tk.Button(window, text="7", width=10,background="lightblue", command=lambda: click_b(7))
b.place(x=20, y=130)

b=tk.Button(window, text="8", width=10,background="lightblue", command=lambda: click_b(8))
b.place(x=120, y=130)

b=tk.Button(window, text="9", width=10,background="lightblue", command=lambda: click_b(9))
b.place(x=220, y=130)

b=tk.Button(window, text="0", width=10,background="lightblue", command=lambda: click_b(0))
b.place(x=20, y=160)

b=tk.Button(window, text="Clear", width=10,background="lightgreen", command=click_clear)
b.place(x=120, y=160)

b=tk.Button(window, text="+", width=10,background="lightgreen", command=lambda: click_b("+"))
b.place(x=220, y=160)

b=tk.Button(window, text="-", width=10,background="lightgreen", command=lambda: click_b("-"))
b.place(x=20, y=190)

b=tk.Button(window, text="*", width=10,background="lightgreen", command=lambda: click_b("*"))
b.place(x=120, y=190)

b=tk.Button(window, text="/", width=10,background="lightgreen", command=lambda: click_b("/"))
b.place(x=220, y=190)

b=tk.Button(window, text="=", width=10,background="lightgreen", command=func_equal)
b.place(x=20, y=220)

window.mainloop()
